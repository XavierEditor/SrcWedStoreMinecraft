<!--<div class="card border-0 shadow mb-4">
                        <div class="card-body">
                            <h5 class="m-0"><i class="fa fa-download fa-fw"></i> ดาวน์โหลดเกม</h5>
                            <hr>
    <a href="http://www.mediafire.com/error.php?errno=378&quickkey=dkba4wd1teeiq6c&origin=download" target="_blank" class="btn btn-lg btn-success btn-block" style="color:#000"><img src="http://www.mc-seksin.com/img/mc_logo.png" style="width:300px;"><br><b>Minecraft</b><br><u>เวอร์ชั่น 1.8</u><br>ดาวน์โหลดตัวเกม</a>
    <p></p>
    <div class="row">
      <div class="col-6">
        <a href="https://java.com/en/download/" target="_blank" class="btn btn-lg btn-danger btn-block" style="color:#000"><b>Java</b><br><u>32Bit</u><br>ดาวน์โหลด Java</a>
      </div>
      <div class="col-6">
        <a href="http://javadl.oracle.com/webapps/download/AutoDL?BundleId=227552_e758a0de34e24606bca991d704f6dcbf" target="_blank" class="btn btn-lg btn-warning btn-block" style="color:#000"><b>Java</b><br><u>64Bit</u><br>ดาวน์โหลด Java</a>
      </div>
    </div>
</div>
</div>
