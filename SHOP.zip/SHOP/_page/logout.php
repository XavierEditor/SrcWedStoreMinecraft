<?php
session_destroy();
      
      echo "<script>window.location.href='?page=home'</script>";
